===================== Folder structure: BILGR for node classification ==============

1. data: Stores all raw and processed data 

2. models: Stores all trained models

3. src_bilgr: Contains all script files

===================== Script decription: BILGR for node classification ==============

1. src_bilgr\make_dataset_Bayesian_obsgraph.py : generates a random graph and compute node criticality class for each node. There are three classes which are defined based on following node criticality score:
[0-0.3]: high,
[0.3-0.7]: Medium, 
[0.7-1.0]: Low 

The theory of node criticality scores can be found at the paper "Scalable Graph Neural Network-based framework for identifying critical nodes and links in Complex Networks"
https://arxiv.org/abs/2012.15725

2. src_bilgr\Graphsage_Supervisclassf_Bayesian.py: Train supervised node classification model (GraphSAGE) with node labels computed on above script.

3. src_bilgr\Graphsage_Supervisclassf_Bayesian_test.py: Test trained node classification model on all nodes of the graph.

4. src_bilgr\utils.py: helping functions

5. src_bilgr\config.py: project path

6. src_bilgr\build_features.py: helping functions for feature extraction

7. src_bilgr\visual.py: helping functions for visualizing data 

=====================================================================================