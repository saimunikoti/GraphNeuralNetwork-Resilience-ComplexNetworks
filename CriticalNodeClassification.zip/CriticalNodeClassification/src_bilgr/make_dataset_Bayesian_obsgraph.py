import networkx as nx

import sys
sys.path.insert(0, r"C:\Users\saimunikoti\Manifestation\PNNL_Internshipwork\CriticalNodeClassification\src_bilgr")
import utils as ut
import config as cnf
import build_features as bf
import pickle
import scipy.io as io
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import random

## ================ generate single random graph, its feature and node labels =====================

fileext = "\\plc_5000_egr_bayesian"
gsize = 5000
gobs = nx.generators.random_graphs.powerlaw_cluster_graph(gsize, 1, 0.1)
nx.write_gpickle(gobs, cnf.datapath +"Bayesian" + fileext + ".gpickle")

Listlabel = []
Listlabel.append(ut.get_estgraphlabel(gobs, "egr", weightflag=1))

with open(cnf.datapath + 'Bayesian'+ fileext + "_label.pickle", 'wb') as b:
    pickle.dump(Listlabel, b)

## ================ load saved graph and  label ==============

gobs = nx.read_gpickle(cnf.datapath + 'Bayesian'+ fileext+".gpickle")

with open(cnf.datapath + 'Bayesian' + fileext+ "_label.pickle", 'rb') as b:
    Listlabel = pickle.load(b)

Labelarray = Listlabel[0]

## === generate target vector by combining labels from all graphs and keep it in target data frame ============

nodelist = list(gobs.nodes)

# gen datagrame of target labels
targetdf = pd.DataFrame()
targetdf['metric'] = Labelarray
targetdf['nodename'] = nodelist
targetdf = targetdf.set_index('nodename')

# targetdf = bf.getgraphtargetdf(Listlabel, nodelist)
# # targetdf.loc[targetdf.metric==0,'metric'] = 0.001

category = pd.cut(targetdf.metric,  bins=[0,0.3,0.7,1.0], labels=[0, 1, 2])
targetdf['metric'] = category
plt.hist(targetdf['metric'])
targetdf = pd.get_dummies(targetdf.metric)

## ====================== assign feature vector to each graph node ==========================

bf.get_graphnodefeatures(gobs)

# ========================== end of script ===============================

