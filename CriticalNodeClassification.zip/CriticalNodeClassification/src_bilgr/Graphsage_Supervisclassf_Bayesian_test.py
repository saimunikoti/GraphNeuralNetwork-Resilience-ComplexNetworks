from stellargraph import StellarGraph
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score
from tensorflow.keras.layers import Dense, Dropout, Input
from stellargraph.mapper import GraphSAGENodeGenerator
from stellargraph.layer import GraphSAGE, MeanPoolingAggregator, MaxPoolingAggregator, MeanAggregator, AttentionalAggregator
import seaborn as sns

import tensorflow as tf
config = tf.compat.v1.ConfigProto(gpu_options =
                         tf.compat.v1.GPUOptions(per_process_gpu_memory_fraction=0.8)
# device_count = {'GPU': 1}
)
config.gpu_options.allow_growth = True
session = tf.compat.v1.Session(config=config)
tf.compat.v1.keras.backend.set_session(session)

from tensorflow.keras import layers, optimizers, losses, metrics, Model, models
from tensorflow.keras.callbacks import ModelCheckpoint, Callback
from sklearn import preprocessing, feature_extraction, model_selection
import matplotlib
matplotlib.use('TkAgg')
from matplotlib import pyplot as plt
import numpy as np
import tensorflow as tf
from sklearn.metrics import classification_report

## = ########################################### build graph ###############################################
#%% ############################################################################################################

G = StellarGraph.from_networkx(gobs, node_features="feature")
print(G.info())

train_subjects, test_subjects = model_selection.train_test_split(targetdf, train_size=0.9, test_size=None)

# temp_train_subjects = np.reshape(np.array(train_subjects), (train_subjects.shape[0],1))
# temp_test_subjects = np.reshape(np.array(test_subjects), (test_subjects.shape[0],1))
# train_targets = target_encoding.fit_transform(temp_train_subjects).toarray()
# test_targets = target_encoding.transform(temp_test_subjects).toarray()

train_targets = np.array(train_subjects)
test_targets = np.array(test_subjects)

batch_size = 40
# number of nodes to consider for each hop
num_samples = [15, 10, 5]
generator = GraphSAGENodeGenerator(G, batch_size, num_samples)

train_gen = generator.flow(train_subjects.index, train_targets, shuffle=True)  # train_subjects.index for selecting training nodes
test_gen = generator.flow(test_subjects.index, test_targets)

## load trained keras model

fileext = "plc_5000_egr_bayesian_mc"
filepath = cnf.modelpath + fileext + '_classf_classweight.h5'

from tensorflow.keras.models import load_model

model = load_model(filepath, custom_objects={"MeanAggregator": MeanAggregator})

all_nodes = targetdf.index
all_mapper = generator.flow(all_nodes)
start = time.time()
y_pred = model.predict(all_mapper)
end = time.time()
print(end - start)

test_targets = np.array(targetdf)
y_test = np.argmax(test_targets, axis=1)
y_pred = np.argmax(y_pred, axis=1)

cnfmatrix = confusion_matrix(y_test, y_pred)
print(cnfmatrix)
accuracy_score(y_test, y_pred)
precision_score(y_test, y_pred, average="weighted")
recall_score(y_test, y_pred, average="weighted")
class0accuracy = cnfmatrix[0][0]/np.sum(cnfmatrix[0,:])
print(class0accuracy)
print(classification_report(y_test, y_pred))

## monte carlo prediction with dropout masks

mc_predictions = []
all_nodes = targetdf.index
all_mapper = generator.flow(all_nodes)

import tqdm
for i in tqdm.tqdm(range(10)):
    y_p = model_est.predict(all_mapper)
    mc_predictions.append(y_p)

def get_ranksfrommetic( mc_predictions):
   listnoderanks=[]
   acclist = []
   class1accuracy = []
   for count in range(mc_predictions.shape[0]):
        temp_pred = np.argmax(mc_predictions[count], axis=1)
        acclist.append(accuracy_score(y_test, temp_pred))
        listnoderanks.append(temp_pred)
        cnfmatrix = confusion_matrix(y_test, temp_pred)
        class1accuracy.append(cnfmatrix[0][0]/np.sum(cnfmatrix[0,:]))

   return np.array(listnoderanks), acclist, class1accuracy

mc_predictions = np.array(mc_predictions)

mc_classpredictions, mc_accuracy, class1accuracy = get_ranksfrommetic(mc_predictions)

Meanaccuracy = np.mean(mc_accuracy)
Varaccuracy = np.var(mc_accuracy)

mc_ensemble_predictions = np.mean(mc_predictions, axis=0)
y_pred_ensemble = np.argmax(mc_ensemble_predictions, axis=1)
ensemble_accuracy = accuracy_score(y_test, y_pred_ensemble)

cnfmatrix = confusion_matrix(y_test, y_pred_ensemble)
print(cnfmatrix)
accuracy_score(y_test, y_pred_ensemble)
precision_score(y_test, y_pred_ensemble, average="weighted")
recall_score(y_test, y_pred_ensemble, average="weighted")
class1accuracy = cnfmatrix[0][0]/np.sum(cnfmatrix[0,:])
print(class1accuracy)
# save report as df
print(classification_report(y_test, y_pred_ensemble))

## class 1 confidence interval

class1_loc = np.where(y_test==0)[0]
mc_predicions_class1 = mc_predictions[:,class1_loc,:]
mc_predicions_class1 = np.max(mc_predicions_class1, axis=2)

## plot class1 samples prob
fig1, ax1 = plt.subplots(nrows=1, ncols=2, sharex=False,sharey=False,figsize=(8,6))

sns.kdeplot(ax=ax1[0], x=mc_predicions_class1[:, 20], shade=True)
ax1[0].set_title("Class-1 Test sample 20", fontsize=18)
ax1[0].set_ylabel("")
ax1[0].tick_params(labelsize=18)
sns.kdeplot(ax=ax1[1], x=mc_predicions_class1[:, 30], shade=True)
ax1[1].set_title("Class-1 Test sample 30", fontsize=18)
ax1[1].set_ylabel("")
ax1[1].tick_params(labelsize=18)

# fig1.suptitle('Variation of class probability for class-1 (high criticality) nodes , fontsize=18)
fig1.text(0.5, 0.04, 'Class probability', ha='center', fontsize=21)
fig1.text(0.09, 0.5, 'Density', va='center', rotation='vertical', fontsize=21)
ax1[0].grid(True)
ax1[1].grid(True)

#========================== end of script ===============================
