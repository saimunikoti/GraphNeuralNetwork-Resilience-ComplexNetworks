
projectpath = r"C:\Users\saimunikoti\Manifestation\PNNL_Internshipwork\CriticalNodeClassification"

datapath = projectpath + "\\data\\"

modelpath = projectpath + "\\models\BayesianGraphsage\\"



